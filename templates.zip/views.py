from django.shortcuts import render
# from django.http import HttpResponse
from .models import Empresa

# Create your views here.


def home(request):
    return render(request, 'home.html')


def cadastro(request):
    if request.method == "POST":
        nome_empresa = request.POST.get('nome_empresa')
        email = request.POST.get('email')
        cidade = request.POST.get('cidade')
        estado = request.POST.get('estado')
        endereco = request.POST.get('endereco')
        nome_unidade = request.POST.get('nome_unidade')
        cnpj = request.POST.get('cnpj')
        setor = request.POST.get('setor')
        porte = request.POST.get('porte')

        empresa = Empresa.objects.create(
            nome_empresa=nome_empresa,
            email=email,
            cidade=cidade,
            estado=estado,
            endereco=endereco,
            nome_unidade=nome_unidade,
            cnpj=cnpj,
            setor=setor,
            porte=porte
        )
        return render(request, 'home.html', {'mensagem': 'Cadastro enviado com sucesso!'})

    return render(request, 'cadastro.html')
