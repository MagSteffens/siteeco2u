from django.db import models

# Create your models here.


class Empresa(models.Model):
    nome_empresa = models.CharField(max_length=100)
    email = models.EmailField()
    cidade = models.CharField(max_length=100)
    estado = models.CharField(max_length=2)
    endereco = models.TextField()
    nome_unidade = models.CharField(max_length=100)
    cnpj = models.CharField(max_length=18)
    setor = models.CharField(max_length=100)
    porte = models.CharField(max_length=50)

    def __str__(self):
        return self.nome_empresa
